<?php 
/***********************/
/****  WooCommerce  ****/ 
/***********************/
?>
<?php woocommerce_content(); ?>