<?php
/**************************************/
/**** Testimonial Preview Template ****/ 
/**************************************/

// Render the quote
echo ac_testimonial_render($post->ID);