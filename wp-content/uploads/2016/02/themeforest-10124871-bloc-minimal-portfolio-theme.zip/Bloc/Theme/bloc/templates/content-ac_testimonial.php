<?php
/**************************************/
/**** Testimonial Preview Template ****/ 
/**************************************/

// Render the testimonial
echo ac_testimonial_render($post->ID);