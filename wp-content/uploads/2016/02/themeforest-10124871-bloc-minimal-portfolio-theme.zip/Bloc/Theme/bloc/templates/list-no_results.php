<?php
/**********************************/
/**** List No Results Template ****/ 
/**********************************/
?>

<div class="alert alert-warning">
  <?php _e('Sorry, no results were found.', 'roots'); ?>
</div>
<?php get_search_form(); ?>
