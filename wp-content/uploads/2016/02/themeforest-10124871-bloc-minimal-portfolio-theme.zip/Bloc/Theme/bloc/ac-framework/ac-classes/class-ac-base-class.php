<?php
/*****************************/
/**** Alleycat Base Class ****/ 
/*****************************/

// Base abstract class

abstract class AC_Base_Class
{
}