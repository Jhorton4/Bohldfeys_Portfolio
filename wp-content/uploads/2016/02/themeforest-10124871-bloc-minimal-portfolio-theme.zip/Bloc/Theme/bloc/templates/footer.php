<?php
/*************************/
/**** Footer Template ****/ 
/*************************/
?>
<a id="page-bottom"></a>
<footer class="content-info <?php echo shoestrap_outer_container_class('footer'); ?>" role="contentinfo">

	<div class='<?php echo shoestrap_container_class('footer-content'); ?>'>
	  <div class="row">
	    <?php shoestrap_footer_content(); ?>
	  </div>
  </div>
    
  <?php shoestrap_footer_html(); ?>
</footer>