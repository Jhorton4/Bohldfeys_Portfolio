<?php
/*******************************/
/**** Single Post Template  ****/ 
/*******************************/
// This is also used for any post type that doesn't have it's own template

ac_gallery_render_bg_gallery(get_the_ID());
?>
