<?php
/**********************************/
/**** Bloc Child - Functions ****/ 
/**********************************/

// Include the child theme style.css
function bloc_child_theme_stylesheet() {
	// Add it right after the main theme style.css
  wp_enqueue_style('ac-child', get_stylesheet_uri(), array('ac-theme'), null);
}
add_action('wp_enqueue_scripts', 'bloc_child_theme_stylesheet', 10050);

// Add you own functions here...
